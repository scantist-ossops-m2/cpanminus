# NAME

CPAN::Dummy::Test::PP - Blah blah blah

# SYNOPSIS

    use CPAN::Dummy::Test::PP;

# DESCRIPTION

CPAN::Dummy::Test::PP is

# AUTHOR

Tatsuhiko Miyagawa <miyagawa@bulknews.net>

# COPYRIGHT

Copyright 2013- Tatsuhiko Miyagawa

# LICENSE

This library is free software; you can redistribute it and/or modify
it under the same terms as Perl itself.

# SEE ALSO
