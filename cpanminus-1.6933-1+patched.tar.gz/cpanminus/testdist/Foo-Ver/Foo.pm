package Foo;
use 5.008_01;
our $VERSION = 0.01;

1;

__END__

=head1 NAME

Foo - Bar

=head1 LICENSE

The same as Perl.

=head1 AUTHOR

Tatsuhiko Miyagawa

=cut
